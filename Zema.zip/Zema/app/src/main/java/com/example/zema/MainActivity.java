package com.example.zema;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

// main class as defined in AndroidManifest.xml
public class MainActivity extends AppCompatActivity {

    // TAG for logging messages
    // just unique string to filter easily
    private static final String TAG = "XXX";

    private SharedPreferences prefs;
    private AppBarConfiguration mAppBarConfiguration;

    // main method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "create main activity");
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        Log.d(TAG, "prefs:" + prefs.getAll().toString());

        // if first run get profile name
        // remove this activity from back button history
        // so user cannot escape by using back button
        // until profile name given the user will always be forced to input profile name
        // if profile name given then skip this step
        if (!prefs.contains("profile_name")) {
            // this will start new activity to get profile name
            Log.d(TAG, "get profile name");
            Intent intent = new Intent(this, SettingsActivity.class);
            intent.putExtra("first_run", true);
            startActivity(intent);
            Log.d(TAG, "finish main activity");
            finish();
            return;
        }
        Log.d(TAG, "has profile name");
        // if we get here we have profile name

        // toolbar three dot menu
        // rest of toolbar handling in
        // corresponding layout xml and some menu xml and maybe more
        // onCreateOptionsMenu
        // onSupportNavigateUp
        // onOptionsItemSelected
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // standard code for sidebar navigation setup
        // the three fragments are collected and put in sidebar
        // see also corresponding layout xml and some more xmls
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        // set profile name in sidebar
        String profileName = prefs.getString("profile_name", "<no profile name>");
        View headerView = navigationView.getHeaderView(0);
        TextView textView = headerView.findViewById(R.id.nav_bar_profile_name);
        textView.setText(profileName);
    }

    // create toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    // support up or back button in toolbar
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    // handle user click on toolbar menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Log.d(TAG, "start settings");
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}