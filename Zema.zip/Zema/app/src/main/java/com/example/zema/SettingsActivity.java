package com.example.zema;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

// setting is own activity (instead of fragment)
// so can handle first run and isolate
// to force user to enter profile name
// because do not know how to isolate using fragment

// this activity is started from main activity
// once on first run
// and whenever user clicks on settings
// intent carries boolean first run indicating first run
// if first run this activity will remove itself from back button history
public class SettingsActivity extends AppCompatActivity {

    private static final String TAG = "XXX";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "create settings activity");
        setContentView(R.layout.activity_settings);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        if (prefs.contains("profile_name")) {
            EditText editText = findViewById(R.id.edit_profile_name);
            String profileName = prefs.getString("profile_name", "<no profile name>");
            editText.setText(profileName);
        }
    }

    // onclick for button (defined in corresponding layout xml)
    // read input
    // check if empty
    // if ok restart main activity
    // and remove self from back button history if first run
    public void enterProfileName(View view) {
        Log.d(TAG, "onClick button profile name");
        EditText editText = findViewById(R.id.edit_profile_name);
        String profileName = editText.getText().toString();
        if (profileName.equals("")) {
            Log.d(TAG, "empty profile name");
            Snackbar.make(view, "enter profile name", Snackbar.LENGTH_LONG).show();
            return;
        }
        prefs.edit().putString("profile_name", profileName).apply();
        Log.d(TAG, "prefs:" + prefs.getAll().toString());
        Intent sendIntent = new Intent(SettingsActivity.this, MainActivity.class);
        startActivity(sendIntent);
        Intent gotIntent = getIntent();
        Boolean firstRun = gotIntent.getBooleanExtra("first_run", false);
        if (firstRun) {
            Log.d(TAG, "finish settings activity because first run");
            finish();
        }
    }
}