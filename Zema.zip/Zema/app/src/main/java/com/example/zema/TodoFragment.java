package com.example.zema;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class TodoFragment extends Fragment {

    private TodoEntryViewModel todoEntryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_todo, container, false);

        // add new todo entry
        FloatingActionButton fab = root.findViewById(R.id.fab_todo);
        fab.setOnClickListener(new View.OnClickListener() {
            // dialog for new entry
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("new entry");
                final EditText input = new EditText(getActivity());
                builder.setView(input);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String text = input.getText().toString();
                        long timestamp = System.currentTimeMillis();
                        TodoEntry entry = new TodoEntry(text, timestamp, false);
                        todoEntryViewModel.insert(entry);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        // viewmodel takes care of data
        todoEntryViewModel = new ViewModelProvider(getActivity()).get(TodoEntryViewModel.class);

        // the todo list display
        RecyclerView recyclerView = root.findViewById(R.id.todolist);
        final TodoEntryListAdapter adapter = new TodoEntryListAdapter(getActivity(), todoEntryViewModel);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // populate todo list display from data
        todoEntryViewModel.getAllEntries().observe(getActivity(), new Observer<List<TodoEntry>>() {
            @Override
            public void onChanged(List<TodoEntry> todoEntries) {
                adapter.setEntries(todoEntries);
            }
        });

        return root;
    }
}