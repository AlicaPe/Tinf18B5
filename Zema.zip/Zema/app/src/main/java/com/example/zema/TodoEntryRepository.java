package com.example.zema;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

// abstract data access
// in this case just a wrapper around database access
// does async data access so to not block gui thread
class TodoEntryRepository {

    private TodoEntryDao todoEntryDao;
    private LiveData<List<TodoEntry>> allEntries;

    TodoEntryRepository(Application application) {
        TodoEntryRoomDatabase db = TodoEntryRoomDatabase.getDatabase(application);
        todoEntryDao = db.todoEntryDao();
        allEntries = todoEntryDao.getEntries();
    }

    LiveData<List<TodoEntry>> getAllEntries() {
        return allEntries;
    }

    void insert(TodoEntry entry) {
        TodoEntryRoomDatabase.databaseWriteExecutor.execute(() -> {
            todoEntryDao.insert(entry);
        });
    }

    public void update(TodoEntry entry) {
        TodoEntryRoomDatabase.databaseWriteExecutor.execute(() -> {
            todoEntryDao.update(entry);
        });
    }

    public void delete(TodoEntry entry) {
        TodoEntryRoomDatabase.databaseWriteExecutor.execute(() -> {
            todoEntryDao.delete(entry);
        });
    }
}
