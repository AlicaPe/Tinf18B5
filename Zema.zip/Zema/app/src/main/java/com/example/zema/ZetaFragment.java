package com.example.zema;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

public class ZetaFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_zeta, container, false);
        final TextView textView = root.findViewById(R.id.text_slideshow);
        textView.setText("This is zeta fragment");

        FloatingActionButton fab = root.findViewById(R.id.fab_slideshow);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "fab zeta", Snackbar.LENGTH_LONG).show();
            }
        });

        return root;
    }
}