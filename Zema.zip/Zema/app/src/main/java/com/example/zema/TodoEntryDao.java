package com.example.zema;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// data access object for TodoEntry
// just standard database methods
// actual database access in TodoEntryRoomDatabase
@Dao
public interface TodoEntryDao {

    @Insert
    void insert(TodoEntry entry);

    @Query("DELETE FROM todo_table")
    void deleteAll();

    @Query("SELECT * from todo_table")
    LiveData<List<TodoEntry>> getEntries();

    @Update
    void update(TodoEntry entry);

    @Delete
    void delete(TodoEntry entry);
}
