package com.example.zema;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// adapter for recycler list containing todo list entries
// this just cares about the list items
// it used by TodoFragment
// gets data from model
// creates the view item
// packs it in recycler list
// also injects listeners so can handle user clicks
public class TodoEntryListAdapter extends RecyclerView.Adapter<TodoEntryListAdapter.TodoEntryHolder> {

    private final LayoutInflater inflater;
    private final Context context;
    private final TodoEntryViewModel model;
    private List<TodoEntry> entries;

    public TodoEntryListAdapter(Context context, TodoEntryViewModel model) {
        this.inflater = LayoutInflater.from(context);
        this.context = context;
        this.model = model;
    }

    @NonNull
    @Override
    public TodoEntryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = inflater.inflate(R.layout.todoentry, parent, false);
        return new TodoEntryHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoEntryHolder holder, int position) {
        if (entries != null) {
            TodoEntry entry = entries.get(position);
            holder.setEntry(entry);
            holder.textView.setText(entry.text);
            holder.checkBox.setChecked(entry.done);
        } else {
            holder.textView.setText("no entries loaded yet");
        }
    }

    void setEntries(List<TodoEntry> entries) {
        this.entries = entries;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (entries != null) {
            return entries.size();
        } else {
            return 0;
        }
    }

    // one list entry in the recycler list
    // hold references to the textview and checkbox and to the todo entry object
    // injects listener to the view items so can handle user clicks
    // on click checkbox update status of todo entry
    // on click text then offer to rename or delete entry
    // new entries are handled in the fragment
    class TodoEntryHolder extends RecyclerView.ViewHolder {

        private final TextView textView;
        private final CheckBox checkBox;
        private TodoEntry entry;

        public TodoEntryHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.todo_entry_text);
            checkBox = itemView.findViewById(R.id.todo_entry_status);
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);

                    builder.setTitle("rename old entry");
                    final EditText input = new EditText(context);
                    input.setText(entry.text);
                    builder.setView(input);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String text = input.getText().toString();
                            entry.text = text;
                            model.update(entry);
                        }
                    });
                    builder.setNeutralButton("Delete",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    model.delete(entry);
                                }
                            });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
            });
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    entry.done = b;
                    model.update(entry);
                }
            });
        }

        public void setEntry(TodoEntry entry) {
            this.entry = entry;
        }
    }
}
