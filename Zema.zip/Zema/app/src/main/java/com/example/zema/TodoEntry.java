package com.example.zema;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// class to hold the attributes of a todo entry
// text, timestamp, and done status
// and bunch of annotation for database access
// works together with TodoEntryDao
@Entity(tableName = "todo_table")
public class TodoEntry {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @NonNull
    @ColumnInfo(name = "text")
    public String text;

    @NonNull
    @ColumnInfo(name = "timestamp")
    public long timestamp;

    @NonNull
    @ColumnInfo(name = "done")
    public boolean done;

    public TodoEntry(@NonNull String text, @NonNull long timestamp, @NonNull boolean done) {
        this.text = text;
        this.timestamp = timestamp;
        this.done = done;
    }

}
