package com.example.zema;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

// abstract data access for view
// in this specific case data access over a so called repository
// which in turn does database access over android room concept
// which in turn does sqlite database access
public class TodoEntryViewModel extends AndroidViewModel {

    private TodoEntryRepository repository;
    private LiveData<List<TodoEntry>> allEntries;

    public TodoEntryViewModel(Application application) {
        super(application);
        repository = new TodoEntryRepository(application);
        allEntries = repository.getAllEntries();
    }

    LiveData<List<TodoEntry>> getAllEntries() {
        return allEntries;
    }

    public void insert(TodoEntry entry) {
        repository.insert(entry);
    }

    public void update(TodoEntry entry) {
        repository.update(entry);
    }

    public void delete(TodoEntry entry) {
        repository.delete(entry);
    }
}
